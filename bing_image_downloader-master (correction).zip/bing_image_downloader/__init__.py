name = "bing_image_downloader"
